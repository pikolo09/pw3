<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MakananController extends Controller
{
    public function tampil()
    $fiki = "saya";
    return view('welcome', ['fiki'=>
    $fiki]);
}

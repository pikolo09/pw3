<?php

use app\Htpp\Controllers\MakananController;
use Illuminate\Support\facades\route;


Route::get('/',[fiki::class, 'tampil']);
